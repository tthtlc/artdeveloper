---
layout: post
title: "Polygon Animation"
tags:
  - Graphics
---
<style>
        body {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        canvas {
            background-color: white;
            border: 1px solid #ccc;
            margin-bottom: 20px;
        }
        .controls {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .controls label {
            margin-right: 10px;
        }
        .controls input {
            margin-bottom: 10px;
        }
        .buttons {
            margin-top: 20px;
        }
        .capture-btn {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .share-links a {
            display: block;
            margin: 5px;
            text-decoration: none;
            color: #007bff;
            font-size: 16px;
        }
    </style>

<canvas height="600" id="animationCanvas" width="600"></canvas>
<div class="controls">
<div>
<label for="sides">Number of sides:</label>
<input id="sides" max="15" min="3" name="sides" step="1" type="range" value="5"/>
<span id="sidesValue">5</span>
</div>
<div>
<label for="largeRadius">Large Radius:</label>
<input id="largeRadius" max="300" min="100" name="largeRadius" step="1" type="range" value="200"/>
<span id="largeRadiusValue">200</span>
</div>
<div>
<label for="smallRadius">Small Radius:</label>
<input id="smallRadius" max="250" min="50" name="smallRadius" step="1" type="range" value="150"/>
<span id="smallRadiusValue">150</span>
</div>
</div>
<div class="buttons">
<button class="capture-btn" id="captureBtn">Capture PNG</button>
<div class="share-links">
<a href="#" id="shareFacebook" target="_blank">Share on Facebook</a>
<a href="#" id="shareWhatsApp" target="_blank">Share on WhatsApp</a>
</div>
</div>
<script>
document.addEventListener("contextmenu", function(event) { event.preventDefault(); });
const canvas = document.getElementById('animationCanvas');
const ctx = canvas.getContext('2d');
let largeRadius = 200; // Initial radius of the larger polygon
let smallRadius = 150; // Initial radius of the smaller polygon
const centerX = canvas.width / 2; // Fixed center X
const centerY = canvas.height / 2; // Fixed center Y
let rotationAngleLarge = 0;
let rotationAngleSmall = 0;
let numSides = 5; // Starting with a pentagon
const numDots = 100; // Number of points along each polygon's perimeter

// Update the displayed values from the sliders
const sidesSlider = document.getElementById('sides');
const sidesValueDisplay = document.getElementById('sidesValue');
const largeRadiusSlider = document.getElementById('largeRadius');
const largeRadiusValueDisplay = document.getElementById('largeRadiusValue');
const smallRadiusSlider = document.getElementById('smallRadius');
const smallRadiusValueDisplay = document.getElementById('smallRadiusValue');

// Event listeners for the scrollbars
sidesSlider.addEventListener('input', (event) => {
    numSides = parseInt(event.target.value);
    sidesValueDisplay.textContent = numSides;
});
largeRadiusSlider.addEventListener('input', (event) => {
    largeRadius = parseInt(event.target.value);
    largeRadiusValueDisplay.textContent = largeRadius;
});
smallRadiusSlider.addEventListener('input', (event) => {
    smallRadius = parseInt(event.target.value);
    smallRadiusValueDisplay.textContent = smallRadius;
});

// Function to generate points along the edge of a polygon, divided into `numDots` points
function getPolygonPoints(centerX, centerY, radius, rotationAngle, numSides, numDots) {
    const points = [];
    const rotationRadians = rotationAngle * Math.PI / 180; // Convert degrees to radians

    // Angle between adjacent vertices of the polygon
    const angleStep = (2 * Math.PI) / numSides;

    // Generate points along the perimeter, divided into numDots parts
    for (let i = 0; i < numDots; i++) {
        const t = i / numDots; // Normalized parameter [0, 1)
        const vertexIndex = Math.floor(t * numSides); // Determine which edge we are on
        const tEdge = (t * numSides) % 1; // Interpolate along the edge

        const angle1 = vertexIndex * angleStep;
        const angle2 = (vertexIndex + 1) * angleStep;

        // Coordinates of the two vertices of the current edge
        const x1 = centerX + radius * Math.cos(angle1);
        const y1 = centerY + radius * Math.sin(angle1);
        const x2 = centerX + radius * Math.cos(angle2);
        const y2 = centerY + radius * Math.sin(angle2);

        // Interpolated point along the current edge
        const x = (1 - tEdge) * x1 + tEdge * x2;
        const y = (1 - tEdge) * y1 + tEdge * y2;

        // Apply rotation
        const rotatedX = centerX + (x - centerX) * Math.cos(rotationRadians) - (y - centerY) * Math.sin(rotationRadians);
        const rotatedY = centerY + (x - centerX) * Math.sin(rotationRadians) + (y - centerY) * Math.cos(rotationRadians);

        points.push({ x: rotatedX, y: rotatedY });
    }

    return points;
}

// Function to draw lines between points of two polygons
function drawLines(points1, points2) {
    for (let i = 0; i < points1.length; i++) {
        ctx.strokeStyle = i % 2 === 1 ? 'blue' : 'red';
        ctx.beginPath();
        ctx.moveTo(points1[i].x, points1[i].y);
        ctx.lineTo(points2[i].x, points2[i].y);
        ctx.stroke();
    }
}

// Function to animate the polygons
function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear the canvas

    // Get points for both polygons, divided by numDots
    const largePolygonPoints = getPolygonPoints(centerX, centerY, largeRadius, rotationAngleLarge, numSides, numDots);
    const smallPolygonPoints = getPolygonPoints(centerX, centerY, smallRadius, rotationAngleSmall, numSides, numDots);

    // Draw lines between corresponding points
    drawLines(largePolygonPoints, smallPolygonPoints);

    // Update rotation angles
    rotationAngleLarge = (rotationAngleLarge + 2) % 360; // Rotate counterclockwise
    rotationAngleSmall = (rotationAngleSmall - 2) % 360; // Rotate clockwise

    requestAnimationFrame(animate); // Continue the animation
}

// Start the animation
animate();

// Capture the canvas as a PNG image
document.getElementById('captureBtn').addEventListener('click', function () {
    const dataURL = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataURL;
    link.download = 'polygon_animation.png';
    link.click();
});

// Share on Facebook
document.getElementById('shareFacebook').addEventListener('click', function () {
    const dataURL = canvas.toDataURL('image/png');
    const facebookShareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(dataURL)}`;
    this.href = facebookShareUrl;
});

// Share on WhatsApp
document.getElementById('shareWhatsApp').addEventListener('click', function () {
    const dataURL = canvas.toDataURL('image/png');
    const whatsappShareUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(dataURL)}`;
    this.href = whatsappShareUrl;
});
    </script>