---
layout: post
title: "Pythagorean Tree Generator"
tags:
  - Graphics
---
<style>
    body {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      font-family: Arial, sans-serif;
    }

    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    form {
      margin-bottom: 20px;
    }

    canvas {
      border: 1px solid #000;
    }
  </style>

<div class="container">
<div>
<label for="angle">Angle (Radians):</label>
<input id="angle" max="1.5" min="0.1" oninput="updateAngle(this.value)" step="0.01" type="range" value="1.04719"/>
<span id="angleValue">1.04719</span>
<br/><br/>
<label for="width">Width:</label>
<input id="width" max="100" min="10" oninput="updateWidth(this.value)" step="1" type="range" value="100"/>
<span id="widthValue">100</span>
</div>
<div>
<!-- The canvas goes on the right of the controls, and the controls do not obstruct the canvas. -->
<canvas id="canv">Your browser does not support the canvas object.</canvas>
</div>
</div>